# Research publication evidence pack

## Purpose and research question

This pack supports review of the pollution-source attribution study: under the specified synthetic advection?dispersion benchmark and configured sensor faults, how do forced-choice attribution and abstention-based selective prediction compare across clean and faulted conditions? It contains the manuscript/research framing, saved experiment artifacts, independent audit outputs, publication figures/tables, and the small set of model/simulation/analysis source files needed to interpret them.

## Experiment and evidence boundary

The confirmatory configuration defines 10 seeds, 13 source classes as reported in the saved report, and 20 episodes per class with 10/3/3/4 train/calibration/validation/test allocation. It evaluates clean baseline and configured stuck/missing sensor conditions. The saved evidence describes 520 paired physical test episodes (1,040 condition-level episode evaluations). This is a synthetic 1D ADE benchmark; these are not measured Noyyal water-quality observations, live sensor readings, or field validation.

## Main findings (pooled; source: `research/results/confirmatory_analysis_v2/independent_metrics.json`)

- Clean default pooled selective risk: M3-Selective 7.92% (40 errors / 505 accepted); M4 7.99% (41 / 513).
- Faulted default pooled selective risk: M3-Selective 19.70% (93 / 472); M4 22.03% (91 / 413).
- Saved M4-minus-M3 risk-difference intervals in `research/results/confirmatory/bootstrap_summary.json`: clean +0.07 percentage points (95% CI ?0.28 to +0.65); faulted +2.33 points (95% CI ?0.72 to +5.59). These saved intervals are attributed to the bootstrap output, with only ten seed clusters. They do not establish M4 superiority or lower risk.
- Nominal target settings do not produce matched achieved test coverage between M3 and M4. M4 has identical saved threshold pairs across the three target settings; why the validation tuner selected those same pairs remains unresolved.

## What this evidence does not support

It does not support claims that M4 is superior, lowers selective risk, performs better at matched achieved coverage, is validated on real Noyyal conditions, or is broadly robust to real-world sensor failures. Do not treat the original report?s faulted 70% infeasibility label or approximate 61.5% ceiling as established: the independent audit flagged these as unsupported. Do not claim novelty/first-of-kind from the combination of methods.

## Run provenance and unresolved items

Saved metadata marks the run complete, but the operating-system process exit code and runtime source provenance were not recorded. The bootstrap output reports 1,000 valid replicates; its uncertainty is limited by ten seed clusters. Target-tuning explanation remains unresolved. Confirm citation/reference details still marked for author verification in `docs/research/manuscript-final-review.md` and `docs/research/related-work-and-gap.md` before submission. Check author names/affiliations, venue requirements, disclosure/IP timing with VIT, and exact reproducibility environment.

## Included-file guide

- `docs/research/`: manuscript draft, methods, plan, literature review, audited results framing, original audit/correction log/final review.
- `research/configs/confirmatory.json`: preregistered settings.
- `research/results/confirmatory/`: saved predictions and run/metric/report artifacts; original files are copied without recomputation.
- `research/results/confirmatory_analysis_v2/`: independent audit, recalculated metrics, figure/table README and assets.
- `research/experiments/`, `research/models/`, `research/simulation/`: relevant runner, bootstrap, feature, diagnostic, model and simulator source; tests are source files only, not a claim that tests were run during packaging.
- `MANIFEST.csv`: archive path, original source path and original byte size for each included file. Missing requested inputs are listed here.

## Excluded materials that may be needed later

Full pilot artifacts and unrelated app assets/code are excluded. The legacy `research/evaluation/results/` summaries are excluded because the evaluator?s expected `research/data/noyyal_observations.csv` is absent, so those numbers cannot be traced to that input in this checkout. Full raw/environment-specific dependency caches, `.git`, `node_modules`, `.next`, and build outputs are excluded. A reproducibility submission may additionally need an environment lock/version record and any verified source-data provenance; do not fabricate these.
