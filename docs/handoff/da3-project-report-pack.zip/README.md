# DA3 project report and teammate handoff pack

## Purpose and evidence standard

This pack gathers current project/setup and research documentation plus a short source map for a DA3 report, demonstration and teammate review. Presence of a route/source file shows implementation exists; it does not prove runtime behavior. The repository?s validation matrix records 27 interactive UI cases and all are `NOT RUN` (0/27). The document reports historical static/build checks, not re-executed results. No application screenshots were found: `docs/research/figure-captions.md` marks nine application figures `PLANNED / NOT CAPTURED`. No UI capture is substituted here.

## Setup notes and known documentation mismatch

The original `README.md` is included as-is, along with `SIMULATION_GUIDE.md`, `package.json`, and `.env.local.example`. The package manifest identifies a Next.js 14.2.5 app with `npm run dev`, `npm run build`, `npm start`, and `npm run lint`. Follow the repository README only after checking prerequisites and secrets locally. **Important:** README describes `ledger/`, `inference/`, and `contracts/` directories and separate services that are not present in the inspected repository tree; those service instructions are not verified as runnable from this checkout. It also makes production/real-time/Bayesian claims that should not be repeated without external runtime evidence. Do not copy secrets into a handoff.

## Architecture and implementation map

- Next.js App Router: `app/`; landing `app/page.tsx`; map `app/map/page.tsx`; 3D/map prototype `app/terrain-map-prototype/page.tsx`; groundwater `app/groundwater/page.tsx`; flood `app/flood-analysis/page.tsx`; scenarios `app/scenarios/page.tsx`.
- API routes: attribution `app/api/attribution/route.ts`; auth login `app/api/auth/login/route.ts`; other routes can be found under `app/api/`.
- Local engines/data: heuristic attribution `lib/attribution/engine.ts`; simulated station readings `lib/digital-twin/sensors.ts`; representative facilities `lib/digital-twin/industrial.ts`; flood score `lib/flood/engine.ts`; groundwater calculator `lib/steri/calculator.ts`; scenario engine `lib/scenarios/engine.ts`; heuristic forecast `lib/prediction/providers/heuristicProvider.ts`. Selected source files are included under their original paths.
- GIS: `public/geo/` contains Noyyal centerline, station and map geometry. OpenStreetMap-derived geometry is not environmental measurement.
- Authentication/database: `lib/auth.ts`, `lib/db.ts`, `prisma/` in the full repository; external DB/deployment availability not tested here.

## Feature and evidence inventory

| Class | Current evidence | Accurate DA3 wording |
|---|---|---|
| Implemented in source; demo candidate | Map and role/page routes; attribution, flood, groundwater, scenarios, citizen/evidence modules | ?Prototype workflow implemented in repository?; show only after a current smoke test. |
| Implemented but unvalidated | UI/API workflows covered by validation matrix; 27 cases are all NOT RUN; demo URL/current external services not verified in this handoff | Do not say ?tested? or ?working end-to-end? until evidence is recorded. |
| Simulated/illustrative/modelled | Sensor values, representative industrial registry, transport trace, point-based flood indicators, scenario inputs, heuristic forecasts, fallback building heights | Label each output as simulated, illustrative, or modelled; not live measurements, verified pathways, forecasts, or legal findings. |
| Synthetic research benchmark | Ten-seed, 13-class synthetic 1D ADE attribution study with configured fault suite | Present separately from application validation; it does not validate real Noyyal conditions. |
| Planned/not evidenced | Live sensor integration, field validation, captured app screenshots, final poster/deck; some README-described services absent from checkout | Label planned/unverified, not implemented or validated. |

The synthetic benchmark?s default pooled selective-risk values do not show lower risk for M4 than M3-Selective. Its nominal target coverage settings do not yield matched achieved test coverage. See the included confirmatory audit/results review.

## Main data sources and limits

- `public/geo/noyyal-river.geojson`, roads/building/industrial geometry: open/map-derived GIS shapes; not survey validation or pollutant measurement.
- `public/geo/tnpcb-noyyal-stations.json`: official station locations as documented; associated demo telemetry values in `lib/digital-twin/sensors.ts` are synthetic, not station observations.
- `lib/digital-twin/industrial.ts`: representative synthetic facility archetypes, not an official industry census or compliance register.
- `data-provenance.md` documents modelled traces, administrative groundwater baseline/scenario assumptions, nominal terrain/building heights, and flood-screening limitations. Check original agency citations before publication. The documented six-versus-33 Firka count discrepancy needs owner/source reconciliation.
- `research/configs/confirmatory.json` and saved research outputs describe a synthetic benchmark and synthetic faults; no real Noyyal validation.

## Existing validation evidence

`docs/research/validation-matrix.md` is included in full. It defines 27 manual UI cases spanning map, tracing, flood, groundwater, scenarios and state isolation; all are NOT RUN. Its static TypeScript/build PASS records are historical entries in that document and were not reproduced for this pack. The included `research/tests/` files are research-code unit test definitions, not application UI validation results. No application screenshot artifacts were located.

## Suggested DA3 project-report outline

1. Title, abstract, 4?6 keywords.
2. Tiruppur/Noyyal problem and the exact selected Tamil Nadu Smart Cities challenge (confirm official wording).
3. Objectives, scope, stakeholders, and DA2-to-DA3 delta (DA2 baseline is not in repository).
4. Related work and requirements.
5. Architecture and implemented modules, with route/source map.
6. Data provenance and methods; distinguish open GIS, administrative sources, synthetic values, models and scenarios.
7. Implementation and tested user workflows.
8. Validation protocol, executed outcomes, defects and limitations; do not present 0/27 as passed.
9. Separate synthetic attribution study with its own results and explicit no-field-validation caveat.
10. Smart City relevance, conclusion, future work, references and appendices.

## Proposed live demo workflow (only after manual smoke-test)

1. Open landing/map and identify the project?s chosen challenge.
2. Toggle Noyyal/station/facility layers; explicitly identify which geometry is GIS and which readings are simulated.
3. Select a facility and show attribution/trace screening with ?modelled estimate? caveat; do not present it as proof of a discharge.
4. Show one groundwater or rainfall scenario and label assumptions/point-based output.
5. Explain validation status and the synthetic research results separately.
6. Have a tested local fallback if the hosted site or external tiles/services are unavailable.

The live URL `https://smart-tiruppur.vercel.app` is listed in the original README; its current availability was not confirmed during the preceding repository audit. Do not claim the suggested workflow has been executed.

## Known problems and questions for the team

- Run/record selected manual validation cases and fix or disclose failures before demo; capture dated screenshots only from observed behavior.
- Confirm current live demo URL, access roles, persistence behavior, and external service owners/URLs. Do not expose credentials in a paper or zip.
- Reconcile README-described missing `ledger/`, `inference/`, `contracts/` services against current deployed architecture.
- Resolve six versus 33 Firka count using geographic scope and a cited authoritative source.
- Recover DA2 submission/feedback to support ?progress beyond DA2.?
- Confirm official Tamil Nadu Smart Cities challenge/problem statement, report format acceptance, poster size, team roles/contributions, and VIT similarity-check process.
- Confirm with VIT IP team whether/how public disclosure should proceed; no patent or Invention Disclosure Form is proposed by this pack.
- Confirm manuscript author/affiliation details and all references flagged for verification.

## Files and index

Original project files retain their repository-relative paths. The supplied DA3 rubric is included at `D:/Downloads/DA3_Smart_Cities_Project_Rubric (1).docx` when accessible. `MANIFEST.csv` lists each archive path, original path, and original byte size. Missing requested files are listed in the manifest. No node_modules, `.git`, `.next`, caches, virtual environments, builds, or whole-project archive are included.
